# Kefalonia Cloudinary Delete API

Deploy this folder to Vercel. Add these Environment Variables in Vercel:

- CLOUDINARY_CLOUD_NAME
- CLOUDINARY_API_KEY
- CLOUDINARY_API_SECRET

Endpoint after deploy:

`https://YOUR-VERCEL-APP.vercel.app/api/delete-cloudinary`
